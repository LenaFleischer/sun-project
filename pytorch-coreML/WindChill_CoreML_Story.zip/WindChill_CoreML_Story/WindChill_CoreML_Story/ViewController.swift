//
//  ViewController.swift
//  WindChill_CoreML_Story
//
//  Created by Lena Fleischer on 2/8/23.
//

import UIKit
import CoreML

class ViewController: UIViewController {

    let model = newmodel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    

    
}

