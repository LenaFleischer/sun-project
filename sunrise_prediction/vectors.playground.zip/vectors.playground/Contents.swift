import UIKit

import Foundation
import CoreML

//lines 7-85 are setting up json decoded keys
struct VectorInfo:Codable {
    var vector: [Double]
}

struct Weather:Codable{
    let remainingCost: Int
    let queryCost: Int
    let messages: String?
    let location: Locations
}

 struct Locations:Codable{
     let stationContributions: String?
     let values: [Values]
     let id: String
     let address: String
     let name: String
     let index: Int
     let latitude: Double
     let longitude: Double
     let distance: Double
     let time: Double
     let tz: String
     let currentConditions: CurrentConditions
     let alerts: String?
 }

struct Values: Codable{
    let wdir: Double
    let uvindex: Double
    let sunrise: String
    let datetimeStr: String
    let precriptype: String?
    let cin: Double
    let cloudcover: Double
    let pop: Double
    let datetime: Int
    let precip: Double
    let solarradiation: Double
    let dew: Double
    let humidity: Double
    let temp: Double
    let visibility: Double
    let wspd: Double
    let severerisk: Double
    let solarenergy: Double
    let heatindex: Double?
    let moonphase: Double
    let snowdepth: Double
    let sealevelpressure: Double
    let snow: Double
    let sunset: String
    let wgust: Double?
    let conditions: String
    let windchill: Double?
    let cape: Double
}

struct CurrentConditions:Codable{
    let wdir: Double
    let temp: Double
    let sunrise: String
    let visibility: Double
    let wspd: Double
    let icon: String
    let stations: String
    let heatindex: Int?
    let cloudcover: Double
    let datetime: String
    let precip: Double
    let moonphase: Double
    let snowdepth: Double?
    let sealevelpressure: Double
    let dew: Double
    let sunset: String
    let humidity: Double
    let wgust: Double?
    let windchill: Double?
}

func decodeAPI(){
    guard let url = URL(string: "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast?locations=ColoradoSprings,CO&aggregateHours=1&forecastDays=1&includeAstronomy=true&unitGroup=us&shortColumnNames=true&contentType=json&locationMode=single&key=4UR84GUK6HRFRTNBQXWNSVFJ4") else{return}

    let task = URLSession.shared.dataTask(with: url){
        data, response, error in
        
        let decoder = JSONDecoder()

        if let data = data{
            do{
                //lines 99-200 are just checking if the sunset/sunrise has passed for the day and to
                //find tomorrow's sunset and sunrise time if so. too much code for this i hate it
                var sunrise = ""
                var sunset = ""
                
                var sunrisePassed = false
                var sunsetPassed = false
                
                let weatherinfo = try decoder.decode(Weather.self, from: data)
                let currentTime = weatherinfo.location.currentConditions.datetime
                let firstHourIndex = currentTime.index(currentTime.startIndex, offsetBy: 11)
                let secondHourIndex = currentTime.index(currentTime.startIndex, offsetBy: 12)
                let firstHour = currentTime[firstHourIndex]
                let secondHour = currentTime[secondHourIndex]
                let hourString = String(firstHour)+String(secondHour)
                let hour = Int(hourString) ?? 0
                
                let sunriseTime = weatherinfo.location.currentConditions.sunrise
                let firstSunriseHourIndex = sunriseTime.index(sunriseTime.startIndex, offsetBy: 11)
                let secondSunriseHourIndex = sunriseTime.index(sunriseTime.startIndex, offsetBy: 12)
                let firstSunriseHour = sunriseTime[firstSunriseHourIndex]
                let secondSunriseHour = sunriseTime[secondSunriseHourIndex]
                let sunriseHourString = String(firstSunriseHour)+String(secondSunriseHour)
                let sunriseHour = Int(sunriseHourString) ?? 0
                
                let sunsetTime = weatherinfo.location.currentConditions.sunset
                let firstSunsetHourIndex = sunsetTime.index(sunsetTime.startIndex, offsetBy: 11)
                let secondSunsetHourIndex = sunsetTime.index(sunsetTime.startIndex, offsetBy: 12)
                let firstSunsetHour = sunsetTime[firstSunsetHourIndex]
                let secondSunsetHour = sunsetTime[secondSunsetHourIndex]
                let sunsetHourString = String(firstSunsetHour)+String(secondSunsetHour)
                let sunsetHour = Int(sunsetHourString) ?? 0
                
                if(hour > sunriseHour){
                    sunrisePassed = true
                }
                
                if(hour > sunsetHour){
                    sunsetPassed = true
                }
                
                if(sunrisePassed){
                    let dateFormatter = DateFormatter()

                    // Set Date Format
                    dateFormatter.dateFormat = "YYYY-MM-dd"

                    // Convert Date to String
                    let tomorrow = dateFormatter.string(from: Date.tomorrow)
                    
                    let dateString = weatherinfo.location.values.first!.datetimeStr
                    
                    let endOfDateIndex = dateString.firstIndex(of: "T")!
                    
                    let endOfDate = dateString[endOfDateIndex...]
                    
                    let thisString = tomorrow + endOfDate
                    
                    var dateChars = Array(thisString)
                    dateChars[11] = "0"
                    dateChars[12] = "0"
                    
                    let correctedString = String(dateChars)
                    
                    weatherinfo.location.values.forEach{ i in
                        if(i.datetimeStr == correctedString){
                            sunrise = i.sunrise
                        }
                    }
                } else {
                    sunrise = weatherinfo.location.values.first!.sunrise
                }
                
                if(sunsetPassed){
                    let dateFormatter = DateFormatter()

                    // Set Date Format
                    dateFormatter.dateFormat = "YYYY-MM-dd"

                    // Convert Date to String
                    let tomorrow = dateFormatter.string(from: Date.tomorrow)
                    
                    let dateString = weatherinfo.location.values.first!.datetimeStr
                    
                    let endOfDateIndex = dateString.firstIndex(of: "T")!
                    
                    let endOfDate = dateString[endOfDateIndex...]
                    
                    let thisString = tomorrow + endOfDate
                    
                    var dateChars = Array(thisString)
                    dateChars[11] = "0"
                    dateChars[12] = "0"
                    
                    let correctedString = String(dateChars)
                    
                    weatherinfo.location.values.forEach{ i in
                        if(i.datetimeStr == correctedString){
                            sunset = i.sunset
                        }
                    }
                } else {
                    sunset = weatherinfo.location.values.first!.sunset
                }
                
                //204-223 is making the string of the sunrise/sunset time match the string for the hour
                //the sunset/sunrise occurs so we can check to get the right hour of forecasted data
                var sunrise_vector = []
                var sunset_vector = []
                
                var sunriseChars = Array(sunrise)
                
                sunriseChars[14] = "0"
                sunriseChars[15] = "0"
                sunriseChars[17] = "0"
                sunriseChars[18] = "0"

                let correctedSunriseTime = String(sunriseChars)
                
                var sunsetChars = Array(sunset)
                
                sunsetChars[14] = "0"
                sunsetChars[15] = "0"
                sunsetChars[17] = "0"
                sunsetChars[18] = "0"

                let correctedSunsetTime = String(sunsetChars)
                
                //227-285: this is creating the vector for the sunrise information
                weatherinfo.location.values.forEach{ i in
                    if(i.datetimeStr == correctedSunriseTime){
                        sunrise_vector.append(i.temp)
                        sunrise_vector.append(i.dew)
                        sunrise_vector.append(i.humidity)
                        if(i.heatindex == nil){
                            sunrise_vector.append(0.0)
                        } else {
                            sunrise_vector.append(i.heatindex!)
                        }
                        sunrise_vector.append(i.wspd)
                        if(i.wgust == nil){
                            sunrise_vector.append(0.0)
                        } else {
                            sunrise_vector.append(i.wgust!)
                        }
                        sunrise_vector.append(i.wdir)
                        if(i.windchill == nil){
                            sunrise_vector.append(0.0)
                        } else {
                            sunrise_vector.append(i.windchill!)
                        }
                        sunrise_vector.append(i.precip)
                        sunrise_vector.append(i.snowdepth)
                        sunrise_vector.append(i.visibility)
                        sunrise_vector.append(i.cloudcover)
                        sunrise_vector.append(i.sealevelpressure)
                        if(i.conditions == "Overcast"){
                            sunrise_vector.append(1.0)
                        } else {
                            sunrise_vector.append(0.0)
                        }
                        if(i.conditions == "Partially cloudy"){
                            sunrise_vector.append(1.0)
                        } else {
                            sunrise_vector.append(0.0)
                        }
                        if(i.conditions == "Clear"){
                            sunrise_vector.append(1.0)
                        } else {
                            sunrise_vector.append(0.0)
                        }
                        if(i.conditions == "Rain"){
                            sunrise_vector.append(1.0)
                        } else {
                            sunrise_vector.append(0.0)
                        }
                        
                        var sunriseChars = Array(sunrise)
                        
                        var month1 = sunriseChars[5]
                        var month2 = sunriseChars[6]
                        var month = String(month1)+String(month2)
                        sunrise_vector.append(Double(month)!)
                        
                        var day1 = sunriseChars[8]
                        var day2 = sunriseChars[9]
                        var day = String(day1)+String(day2)
                        sunrise_vector.append(Double(day)!)
                    }
                    //287-347 is creating the vector of the sunset forecast
                    if(i.datetimeStr == correctedSunsetTime){
                        sunset_vector.append(i.temp)
                        sunset_vector.append(i.dew)
                        sunset_vector.append(i.humidity)
                        if(i.heatindex == nil){
                            sunset_vector.append(0.0)
                        } else {
                            sunset_vector.append(i.heatindex!)
                        }
                        sunset_vector.append(i.wspd)
                        if(i.wgust == nil){
                            sunset_vector.append(0.0)
                        } else {
                            sunset_vector.append(i.wgust!)
                        }
                        sunset_vector.append(i.wdir)
                        if(i.windchill == nil){
                            sunset_vector.append(0.0)
                        } else {
                            sunset_vector.append(i.windchill!)
                        }
                        sunset_vector.append(i.precip)
                        sunset_vector.append(i.snowdepth)
                        sunset_vector.append(i.visibility)
                        sunset_vector.append(i.cloudcover)
                        sunset_vector.append(i.sealevelpressure)
                        if(i.conditions == "Overcast"){
                            sunset_vector.append(1.0)
                        } else {
                            sunset_vector.append(0.0)
                        }
                        if(i.conditions == "Partially cloudy"){
                            sunset_vector.append(1.0)
                        } else {
                            sunset_vector.append(0.0)
                        }
                        if(i.conditions == "Clear"){
                            sunset_vector.append(1.0)
                        } else {
                            sunset_vector.append(0.0)
                        }
                        if(i.conditions == "Rain"){
                            sunset_vector.append(1.0)
                        } else {
                            sunset_vector.append(0.0)
                        }
                        
                        var sunsetChars = Array(sunset)
                        
                        var month1 = sunsetChars[5]
                        var month2 = sunsetChars[6]
                        var month = String(month1)+String(month2)
                        sunset_vector.append(Double(month)!)
                        
                        var day1 = sunsetChars[8]
                        var day2 = sunsetChars[9]
                        var day = String(day1)+String(day2)
                        sunset_vector.append(Double(day)!)
                        
                    }
                }

                //loading json files for mean and std
                var mean_vector_info = loadJson(filename: "mean")!
                var std_vector_info = loadJson(filename: "std")!
                
                //356-361
                //going through each index to do the operation; swift doesn't seem to be able to
                //do matrix mulitplication and such
                var index = 0
                while(index < 19){
                    sunrise_vector[index] = (sunrise_vector[index] as! Double - mean_vector_info.vector[index])/(std_vector_info.vector[index])
                    sunset_vector[index] = (sunset_vector[index] as! Double - mean_vector_info.vector[index])/(std_vector_info.vector[index])
                    index+=1
                }
                
                //making the multiarrays
                guard let sunriseArray = try? MLMultiArray(shape:[19], dataType:MLMultiArrayDataType.float32) else {
                        fatalError("Unexpected runtime error. MLMultiArray")
                }
                for (index, element) in sunrise_vector.enumerated() {
                    sunriseArray[index] = NSNumber(floatLiteral: element as! Double)
                }
                
                guard let sunsetArray = try? MLMultiArray(shape:[19], dataType:MLMultiArrayDataType.float32) else {
                        fatalError("Unexpected runtime error. MLMultiArray")
                }
                for (index, element) in sunset_vector.enumerated() {
                    sunsetArray[index] = NSNumber(floatLiteral: element as! Double)
                }
                
                print(sunriseArray)
                print(sunsetArray)
                
            }catch{
                print(error)
            }
        }
    }
    task.resume()

}
decodeAPI()

//needed for finding the correct sunrise/sunset times
extension Date {
   static var tomorrow:  Date { return Date().dayAfter }
   static var today: Date {return Date()}
   var dayAfter: Date {
      return Calendar.current.date(byAdding: .day, value: 1, to: Date())!
   }
}

//to load mean and std
func loadJson(filename fileName: String) -> VectorInfo? {
    if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            let jsonData = try decoder.decode(VectorInfo.self, from: data)
            return jsonData
        } catch {
            print("error:\(error)")
        }
    }
    return nil
}
